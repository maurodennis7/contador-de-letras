
function countLeters(){

    const input = document.querySelector("input#palavra");
    const resul = document.querySelector("div.resul")

    input.addEventListener("input", () => {
       
        resul.style.display = 'block';
        const inpValue = input.value;

        let space = [];
        for(valor of inpValue){
            if(valor !== ' '){
                space.push(valor);
            }
        }
        resul.innerHTML = `A frase tem ${space.length} letras!`
    });

}
countLeters();